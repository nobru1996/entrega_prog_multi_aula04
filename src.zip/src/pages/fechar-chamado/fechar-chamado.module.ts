import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FecharChamadoPage } from './fechar-chamado';

@NgModule({
  declarations: [
    FecharChamadoPage,
  ],
  imports: [
    IonicPageModule.forChild(FecharChamadoPage),
  ],
})
export class FecharChamadoPageModule {}
